#!/bin/bash
mfba.py -r rea_sulfolobus.txt -p mFBA_raw.txt -m mFBA_matrix.txt -o mFBA.txt -v