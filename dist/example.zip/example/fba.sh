#!/bin/bash
fba.py -r rea_sulfolobus.txt -p sce_sulfolobus.sce -o fba_sulfolobus.fba
